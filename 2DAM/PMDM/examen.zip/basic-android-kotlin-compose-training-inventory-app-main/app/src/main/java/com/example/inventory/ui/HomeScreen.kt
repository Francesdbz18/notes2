package com.example.inventory.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.inventory.data.AppDatabase
import com.example.inventory.data.Registro
    @Composable
    fun HomeScreen(
        navController: NavController,
        db: AppDatabase
    ) {
        val registros = remember { mutableStateOf(listOf<Registro>()) }
        LaunchedEffect(true) {
            registros.value = db.registroDao().getAllRegistros()
        }
        Column(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(100.dp)
                    .background(Color.Blue),
                contentAlignment = Alignment.Center
            ) {
                Button(onClick = {
                    val registrosGenerados = generarRegistros()
                    registros.value = registrosGenerados
                    db.registroDao().insertAll(registros = registrosGenerados.toTypedArray())
                }) {
                    Text("Generar Registros")
                }
            }
            LazyColumn {
                items(registros.value) { registro ->
                    RegistroItem(registro, navController)
                }
            }
        }
    }

    @Composable
    fun RegistroItem(registro: Registro, navController: NavController) {
        Card(modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clickable {
                navController.navigate("detalles/${registro.id}")
            }) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "Nombre: ${registro.nombre}")
                Text(text = "Edad: ${registro.edad}")
                Text(text = "Código: ${registro.codigo}")
            }
        }
    }


    fun generarRegistros(): List<Registro> {
        return List(10) { index ->
            Registro(
                nombre = "Pepito $index",
                edad = (18..60).random(),
                codigo = (1001..9999).random()
            )
        }
    }

    @Composable
    fun DetalleScreen(id: Int, db: AppDatabase) {
        val registro = remember { mutableStateOf<Registro?>(null) }
        LaunchedEffect(true) {
            registro.value = db.registroDao().getRegistroById(id)
        }
        registro.value?.let { registro ->
            Column(modifier = Modifier.fillMaxSize()) {
                Text(text = "Nombre: ${registro.nombre}")
                Text(text = "Edad: ${registro.edad}")
                Text(text = "Código: ${registro.codigo}")
            }
            Button(onClick = { /* Volver a la pantalla principal */ }) {
                Text("Volver")
            }
        }
    }

    @Composable
    fun AppNavHost(navController: NavController, db: AppDatabase) {
        val navHostController = rememberNavController()
        NavHost(navController = navHostController, startDestination = "main") {
            composable("main") {
                HomeScreen(navController = navController, db = db)
            }
            composable("detalles/{id}") { backStackEntry ->
                val id = backStackEntry.arguments?.getString("id")?.toInt() ?: 0
                DetalleScreen(id = id, db = db)
            }
        }
    }
