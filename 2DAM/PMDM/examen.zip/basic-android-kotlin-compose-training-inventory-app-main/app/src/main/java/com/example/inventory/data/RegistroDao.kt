package com.example.inventory.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface RegistroDao {
    @Insert
    fun insertAll(vararg registros: Registro)
    @Query("SELECT * FROM registro")
    fun getAllRegistros(): List<Registro>
    @Query ("SELECT * FROM registro WHERE id = :id")
    fun getRegistroById(id: Int): Registro?
}
