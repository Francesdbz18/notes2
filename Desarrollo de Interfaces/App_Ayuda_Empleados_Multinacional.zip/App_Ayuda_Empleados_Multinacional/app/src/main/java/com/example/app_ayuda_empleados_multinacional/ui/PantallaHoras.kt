package com.example.app_ayuda_empleados_multinacional.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults.topAppBarColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.app_ayuda_empleados_multinacional.viewmodel.ViewModelHoras
import com.example.practicainterfaces.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppHoras(
    viewModel: ViewModelHoras = viewModel(),
    navegarTemperatura: () -> Unit,
    navegarTelefonos: () -> Unit
) {

    val ciudadSeleccionada by viewModel.ciudadSeleccionada.collectAsState()
    val horaSeleccionada by viewModel.horaSeleccionada.collectAsState()
    val horaCiudad by viewModel.horaCiudad.collectAsState()


    Scaffold(
        topBar = {
            TopAppBar(
                colors = topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.outlineVariant,
                    titleContentColor = MaterialTheme.colorScheme.error,
                ),
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "S", color = Color(0xFFD12926), fontSize = 30.sp, fontFamily = FontFamily.SansSerif)
                        Text(text = "plat", color = Color(0xFF525237), fontSize = 30.sp, fontFamily = FontFamily.SansSerif)
                        Text(text = "not", color = Color(0xFFD1D126), fontSize = 30.sp, fontFamily = FontFamily.SansSerif)
                    }
                },
                navigationIcon = {
                    Image(
                        painter = painterResource(id = R.drawable.splatnot),
                        contentDescription = "App Logo",
                        modifier = Modifier.size(90.dp)
                    )
                },
                actions = {
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Person, contentDescription = "Login")
                    }
                }
            )
        },
        bottomBar = {
            BottomAppBar(containerColor = MaterialTheme.colorScheme.outlineVariant,
                contentColor = MaterialTheme.colorScheme.error,
            ){
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ){
                    Button(onClick = {navegarTemperatura()}){
                        Image(
                            painter = painterResource(id = R.drawable.thermometericon),
                            contentDescription = "Imagen Termometro",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Button(onClick = {}){
                        Image(
                            painter = painterResource(id = R.drawable.clockicon),
                            contentDescription = "Icono reloj",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Button(onClick = {navegarTelefonos()}){
                        Image(
                            painter = painterResource(id = R.drawable.phoneicon),
                            contentDescription = "Icono telefono",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }
    ) { PaddingValues ->
        Column(modifier = Modifier.fillMaxSize()
            .padding(16.dp)
            .padding(PaddingValues())
        ) {
            SelectorCiudad(viewModel)
            Spacer(modifier = Modifier.height(16.dp))
            HoraCiudad(ciudad = ciudadSeleccionada, hora = horaSeleccionada)
            Spacer(modifier = Modifier.height(16.dp))
            HorasCiudades(horaCiudad)
        }


    }
}

@Composable
fun SelectorCiudad(viewModel: ViewModelHoras) {
    val ciudades = listOf("Madrid", "París", "Londres", "Porto Alegre", "Acapulco", "Vancouver", "Houston", "Casablanca", "Osaka", "Melbourne", "Ankara", "Dubai")
    LazyRow(modifier = Modifier.fillMaxWidth()) {
        items(ciudades) { city ->
            Button(onClick = { viewModel.actualizarCiudadSeleccionada(city) }) {
                Text(city)
            }
            Spacer(modifier = Modifier.width(10.dp))
        }
    }
}

@Composable
fun HoraCiudad(ciudad: String, hora: String) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.clock),
            contentDescription = "$ciudad Map",
            modifier = Modifier.size(100.dp)
        )
        Text(ciudad, style = MaterialTheme.typography.headlineMedium)
        Text(hora, style = MaterialTheme.typography.displayLarge)
    }
}

@Composable
fun HorasCiudades(horas: Map<String, String>) {
    Column(modifier = Modifier.fillMaxWidth()) {
        horas.forEach { (city, time) ->
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Image(painter = painterResource(id = R.drawable.clock), contentDescription = "$city Map", modifier = Modifier.size(50.dp))
                Text(city, style = MaterialTheme.typography.bodyLarge)
                Text(time, style = MaterialTheme.typography.bodyLarge)
            }
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}

@Composable
fun HoraActual(viewModel: ViewModelHoras) {
    val ciudad by viewModel.ciudadSeleccionada.collectAsState()
    val hora by viewModel.horaSeleccionada.collectAsState()

    HoraCiudad(ciudad = ciudad, hora = hora)
}


@Preview(showBackground = true)
@Composable
fun AppHorasPreview() {
    AppHoras(navegarTemperatura = {}, navegarTelefonos = {})
}
