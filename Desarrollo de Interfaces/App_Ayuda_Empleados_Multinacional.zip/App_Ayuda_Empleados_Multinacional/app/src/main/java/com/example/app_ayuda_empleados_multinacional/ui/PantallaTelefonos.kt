package com.example.app_ayuda_empleados_multinacional.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults.topAppBarColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.app_ayuda_empleados_multinacional.viewmodel.ViewModelTelefonos
import com.example.practicainterfaces.R

data class InformacionCiudades(
    val city: String,
    val country: String,
    val phoneNumber: String,
    val contactName: String?,
    val contactInfo: String?,
    val mapResource: Int // Resource ID for the map image
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTelefonos(
    viewModel: ViewModelTelefonos = viewModel(),
    navegarHoras: () -> Unit,
    navegarTemperatura: () -> Unit
) {

    val ciudades = viewModel.ListaCiudades.map { it.city }
    var ciudadSeleccionada by remember { mutableStateOf(viewModel.ciudadSeleccionada) }

    // Save the selected city to the ViewModel when it changes
    LaunchedEffect(ciudadSeleccionada) {
        viewModel.ciudadSeleccionada = ciudadSeleccionada
    }

    // Find the selected city information
    val InfoCiudad = viewModel.ListaCiudades.find { it.city == ciudadSeleccionada } ?: viewModel.ListaCiudades.first()


    Scaffold(
        topBar = {
            TopAppBar(
                colors = topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.outlineVariant,
                    titleContentColor = MaterialTheme.colorScheme.error,
                ),
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "S", color = Color(0xFFD12926), fontSize = 30.sp, fontFamily = FontFamily.SansSerif)
                        Text(text = "plat", color = Color(0xFF525237), fontSize = 30.sp, fontFamily = FontFamily.SansSerif)
                        Text(text = "not", color = Color(0xFFD1D126), fontSize = 30.sp, fontFamily = FontFamily.SansSerif)
                    }
                },
                navigationIcon = {
                    Image(
                        painter = painterResource(id = R.drawable.splatnot),
                        contentDescription = "App Logo",
                        modifier = Modifier.size(90.dp)
                    )
                },
                actions = {
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Person, contentDescription = "Login")
                    }
                }
            )
        },
        bottomBar = {
            BottomAppBar(containerColor = MaterialTheme.colorScheme.outlineVariant,
                contentColor = MaterialTheme.colorScheme.error,
            ){
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ){
                    Button(onClick = {navegarTemperatura()}){
                        Image(
                            painter = painterResource(id = R.drawable.thermometericon),
                            contentDescription = "Icono Termometro",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Button(onClick = {navegarHoras()}){
                        Image(
                            painter = painterResource(id = R.drawable.clockicon),
                            contentDescription = "Icono reloj",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Button(onClick = {}){
                        Image(
                            painter = painterResource(id = R.drawable.phoneicon),
                            contentDescription = "Icono telelfono",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        Column (
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            Text("Telefonos de Emergencia", fontSize = 30.sp, style = MaterialTheme.typography.headlineSmall)

            Row(
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                DropdownMenuComponent(nombre = "Ciudad", ciudades = ciudades, ciudadSeleccionada = ciudadSeleccionada) { ciudadSeleccionada = it }
            }
            Box(contentAlignment = Alignment.Center) {
                // Mapa de la ciudad elegida
                Image(
                    painter = painterResource(id = InfoCiudad.mapResource),
                    contentDescription = "Mapa de ${InfoCiudad.city}",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                )
                // Numero de telefono
                Text(
                    text = InfoCiudad.phoneNumber,
                    fontSize = 35.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
            }
            // Nombre de la ciudad y el pais
            Text(text = "${InfoCiudad.city}, ${InfoCiudad.country}", fontSize = 24.sp, fontWeight = FontWeight.Bold)
            // Informacion de contacto
            InfoCiudad.contactName?.let {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "Persona de contacto", fontSize = 20.sp, fontWeight = FontWeight.Medium)
                    Text(text = it, fontSize = 18.sp)
                    InfoCiudad.contactInfo?.let { info ->
                        Text(text = info, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun DropdownMenuComponent(
    nombre: String,
    ciudades: List<String>,
    ciudadSeleccionada: String,
    seleccionado: (String) -> Unit
) {
    var expandir by remember { mutableStateOf(false) }
    Column {
        Text(text = nombre, fontSize = 19.sp, fontWeight = FontWeight.Medium)
        Button(onClick = { expandir = true }) {
            Text(text = ciudadSeleccionada)
        }
        DropdownMenu(expanded = expandir, onDismissRequest = { expandir = false }) {
            ciudades.forEach { item ->
                DropdownMenuItem(
                    text = { Text(text = item) },
                    onClick = {
                        seleccionado(item)
                        expandir = false
                    }
                )
            }
        }
    }
}


@Preview(showBackground = true)
@Composable
fun AppTelefonoPreview() {
    AppTelefonos(navegarTemperatura = {}, navegarHoras = {})
}
