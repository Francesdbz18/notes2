package com.example.app_ayuda_empleados_multinacional.navegacion

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.app_ayuda_empleados_multinacional.ui.AppHoras
import com.example.app_ayuda_empleados_multinacional.ui.AppTelefonos
import com.example.app_ayuda_empleados_multinacional.ui.AppTemperatura


@Composable
fun ControlarNavegacion() {
    val controladorNavegacion = rememberNavController()

    NavHost(navController = controladorNavegacion, startDestination = PantallaTemperatura){
        composable<PantallaTemperatura> {
            AppTemperatura(
                navegarHoras = {controladorNavegacion.navigate(PantallaHoras)},
                navegarTelefonos = {controladorNavegacion.navigate(PantallaTelefonos)}
            )
        }
        composable<PantallaHoras> {
            AppHoras(
                navegarTemperatura = {controladorNavegacion.navigate(PantallaTemperatura)},
                navegarTelefonos = {controladorNavegacion.navigate(PantallaTelefonos)}
            )
        }
        composable<PantallaTelefonos> {
            AppTelefonos(
                navegarHoras = {controladorNavegacion.navigate(PantallaHoras)},
                navegarTemperatura = {controladorNavegacion.navigate(PantallaTemperatura)}
            )
        }
    }
}