package com.example.app_ayuda_empleados_multinacional.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

class ViewModelHoras : ViewModel() {
    private val ciudadElegida = MutableStateFlow("Madrid")
    val ciudadSeleccionada = ciudadElegida.asStateFlow()

    private val horaElegida = MutableStateFlow(getCurrentTime("Europe/Madrid"))
    val horaSeleccionada = horaElegida.asStateFlow()

    private val horasCiudad = MutableStateFlow<Map<String, String>>(emptyMap())
    val horaCiudad = horasCiudad.asStateFlow()

    private val cityTimeZones = mapOf(
        "Madrid" to "Europe/Madrid",
        "París" to "Europe/Paris",
        "Londres" to "Europe/London",
        "Porto Alegre" to "America/Sao_Paulo",
        "Acapulco" to "America/Mexico_City",
        "Vancouver" to "America/Vancouver",
        "Houston" to "America/Chicago",
        "Casablanca" to "Africa/Casablanca",
        "Osaka" to "Asia/Tokyo",
        "Melbourne" to "Australia/Melbourne",
        "Ankara" to "Europe/Istanbul",
        "Dubai" to "Asia/Dubai"
    )

    init {
        iniciarActualizacionHora()
    }

    private fun iniciarActualizacionHora() {
        viewModelScope.launch {
            while (true) {
                actualizarHoras()
                delay(1000) // Actualiza cada segundo
            }
        }
    }

    fun actualizarCiudadSeleccionada(ciudad: String) {
        ciudadElegida.value = ciudad
        actualizarHoras()
    }

    private fun actualizarHoras() {
        val zonaReferencia = ZoneId.of(cityTimeZones[ciudadSeleccionada.value] ?: "UTC")
        val horaActualizada = getCurrentTime(zonaReferencia.id)
        horaElegida.value = horaActualizada

        val horasActualizadas = cityTimeZones.mapValues { (_, zoneId) ->
            getCurrentTime(zoneId)
        }

        horasCiudad.value = horasActualizadas
    }

    private fun getCurrentTime(zoneId: String): String {
        val zona = ZoneId.of(zoneId)
        val hora = ZonedDateTime.now(zona)
        return hora.format(DateTimeFormatter.ofPattern("HH:mm:ss")) // Se actualiza con segundos
    }
}
