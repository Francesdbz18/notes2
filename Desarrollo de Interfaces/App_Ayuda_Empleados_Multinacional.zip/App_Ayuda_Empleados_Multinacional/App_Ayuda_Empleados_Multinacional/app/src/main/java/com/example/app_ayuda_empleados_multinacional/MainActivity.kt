package com.example.app_ayuda_empleados_multinacional

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults.topAppBarColors
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.app_ayuda_empleados_multinacional.navegacion.ControlarNavegacion
import com.example.app_ayuda_empleados_multinacional.ui.theme.App_Ayuda_Empleados_MultinacionalTheme

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            App_Ayuda_Empleados_MultinacionalTheme {
                /*
                Scaffold(
                    topBar = {
                        TopAppBar(
                            colors = topAppBarColors(
                                containerColor = MaterialTheme.colorScheme.outlineVariant,
                                titleContentColor = MaterialTheme.colorScheme.error,
                            ),
                            title = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "S",
                                        color = Color(0xFFD12926),
                                        fontSize = 30.sp,
                                        fontFamily = FontFamily.SansSerif
                                    )
                                    Text(
                                        text = "plat",
                                        color = Color(0xFF525237),
                                        fontSize = 30.sp,
                                        fontFamily = FontFamily.SansSerif
                                    )
                                    Text(
                                        text = "not",
                                        color = Color(0xFFD1D126),
                                        fontSize = 30.sp,
                                        fontFamily = FontFamily.SansSerif
                                    )
                                }
                            },
                            navigationIcon = {
                                Image(
                                    painter = painterResource(id = R.drawable.splatnot),
                                    contentDescription = "App Logo",
                                    modifier = Modifier.size(90.dp)
                                )
                            },
                            actions = {
                                IconButton(onClick = {}) {
                                    Icon(Icons.Default.Settings, contentDescription = "Settings")
                                }
                                IconButton(onClick = {}) {
                                    Icon(Icons.Default.Person, contentDescription = "Login")
                                }
                            }
                        )
                    }
                ) { paddingValues ->
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingValues)
                            .padding(16.dp),
                        verticalArrangement = Arrangement.Top,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        ControlarNavegacion()
                    }
                }
                */
                ControlarNavegacion()
            }
        }
    }
}

