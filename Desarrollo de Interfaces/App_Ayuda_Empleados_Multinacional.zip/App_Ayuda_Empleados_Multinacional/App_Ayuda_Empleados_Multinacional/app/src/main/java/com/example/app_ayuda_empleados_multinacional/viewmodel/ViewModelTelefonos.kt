package com.example.app_ayuda_empleados_multinacional.viewmodel

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import com.example.app_ayuda_empleados_multinacional.ui.InformacionCiudades
import com.example.practicainterfaces.R


class ViewModelTelefonos(savedStateHandle: SavedStateHandle) : ViewModel() {
    private val savedState = savedStateHandle
    val ListaCiudades = listOf(
        InformacionCiudades("Madrid", "España", "123-456-789", "Juan Pérez", "Responsable del servicio", R.drawable.madrid),
        InformacionCiudades("París", "Francia", "234-567-890", "Marie Dupont", "Jefa de operaciones", R.drawable.paris),
        InformacionCiudades("Londres", "Reino Unido", "345-678-901", null, null, R.drawable.londres),
        InformacionCiudades("Porto Alegre", "Brasil", "456-789-012", "Carlos Silva", "Encargado de seguridad", R.drawable.porto_alegre),
        InformacionCiudades("Acapulco", "México", "567-890-123", "Ana López", "Atención al cliente", R.drawable.acapulco),
        InformacionCiudades("Vancouver", "Canadá", "678-901-234", "John Smith", "Director regional", R.drawable.vancouver),
        InformacionCiudades("Houston", "Estados Unidos de América", "789-012-345", null, null, R.drawable.houston),
        InformacionCiudades("Casablanca", "Marruecos", "890-123-456", "Fatima Zahra", "Responsable de soporte", R.drawable.casablanca),
        InformacionCiudades("Osaka", "Japón", "901-234-567", "Taro Yamada", "Jefe de logística", R.drawable.osaka),
        InformacionCiudades("Melbourne", "Australia", "012-345-678", "Emma Brown", "Gerente de ventas", R.drawable.melbourne),
        InformacionCiudades("Ankara", "Turquía", "123-678-901", "Ahmet Kaya", "Responsable de operaciones", R.drawable.ankara),
        InformacionCiudades("Dubai", "Emiratos Árabes Unidos", "234-789-012", "Layla Al Mansoori", "Directora de servicios", R.drawable.dubai)
    )
    var ciudadSeleccionada: String
        get() = savedState.get<String>("ciudadSeleccionada") ?:ListaCiudades.first().city
        set(value) {
            savedState["ciudadSeleccionada"] = value
        }
}