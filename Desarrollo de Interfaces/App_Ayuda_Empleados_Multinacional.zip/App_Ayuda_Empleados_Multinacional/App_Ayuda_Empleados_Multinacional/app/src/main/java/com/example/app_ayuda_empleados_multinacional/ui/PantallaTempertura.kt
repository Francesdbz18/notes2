package com.example.app_ayuda_empleados_multinacional.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.BottomAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults.topAppBarColors
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.rememberNavController
import com.example.app_ayuda_empleados_multinacional.viewmodel.ViewModelTemperatura
import com.example.practicainterfaces.R

@Composable
fun celsiusAFahrenheit(celsius: Int): Int {
    return ((celsius * 9 / 5) + 32)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTemperatura(
    viewModel: ViewModelTemperatura = viewModel(),
    navegarHoras: () -> Unit,
    navegarTelefonos: () -> Unit
) {
    val temperatura = viewModel.temperaturaCelsius
    val Fahrenheit = viewModel.usarFarenheit
    val temperaturasGuardadas = viewModel.guardarTemperaturas
    val controladorNav = rememberNavController()

    Scaffold(
        topBar = {
            TopAppBar(
                colors = topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.outlineVariant,
                    titleContentColor = MaterialTheme.colorScheme.error,
                ),
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(text = "S", color = Color(0xFFD12926), fontSize = 30.sp, fontFamily = FontFamily.SansSerif)
                        Text(text = "plat", color = Color(0xFF525237), fontSize = 30.sp, fontFamily = FontFamily.SansSerif)
                        Text(text = "not", color = Color(0xFFD1D126), fontSize = 30.sp, fontFamily = FontFamily.SansSerif)
                    }
                },
                navigationIcon = {
                    Image(
                        painter = painterResource(id = R.drawable.splatnot),
                        contentDescription = "App Logo",
                        modifier = Modifier.size(90.dp)
                    )
                },
                actions = {
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                    IconButton(onClick = {}) {
                        Icon(Icons.Default.Person, contentDescription = "Login")
                    }
                }
            )
        },
        bottomBar = {
            BottomAppBar(containerColor = MaterialTheme.colorScheme.outlineVariant,
                contentColor = MaterialTheme.colorScheme.error,
            ){
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ){
                    Button(onClick = {}){
                        Image(
                            painter = painterResource(id = R.drawable.thermometericon),
                            contentDescription = "Icono Termometro",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Button(onClick = {navegarHoras()}){
                        Image(
                            painter = painterResource(id = R.drawable.clockicon),
                            contentDescription = "Icono reloj",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Button(onClick = {navegarTelefonos()}){
                        Image(
                            painter = painterResource(id = R.drawable.phoneicon),
                            contentDescription = "Icono telelfono",
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(10.dp))
            Text("Conversión de temperatura", style = MaterialTheme.typography.headlineSmall)//revisar la tipografia
            Spacer(modifier = Modifier.height(18.dp))
            Text("Select Temperature: ${if (Fahrenheit) celsiusAFahrenheit(temperatura.toInt()) else temperatura.toInt()} ${if (Fahrenheit) "°F" else "°C"}", fontSize = 20.sp)
            Slider(
                value = temperatura,
                onValueChange = { viewModel.updateTemperature(it) },
                modifier = Modifier .width(280.dp),
                valueRange = -30f..55f
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Celsius", fontSize = 20.sp)
                Switch(
                    checked = Fahrenheit,
                    onCheckedChange = { viewModel.toggleFahrenheit() }
                )
                Text("Fahrenheit", fontSize = 20.sp)
            }
            Button(onClick = { viewModel.guardarTemperaturas }) {
                Text("Guardar Temperatura", fontSize = 18.sp)
            }
            Spacer(modifier = Modifier.height(19.dp))

            Box(
                modifier = Modifier
                    .width(170.dp)
                    .height(170.dp)
                    .background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.thermometer),
                    contentDescription = "Imagen Termometro",
                    modifier = Modifier.fillMaxSize()
                )
                Row(){
                    Text("${temperatura.toInt()}°C ",modifier = Modifier .padding(12.dp), fontSize = 20.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("${celsiusAFahrenheit(temperatura.toInt())}°F",modifier = Modifier .padding(12.dp), fontSize = 20.sp)
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
            LazyColumn(modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally) {
                items(temperaturasGuardadas) { temp ->
                    Row(
                        modifier = Modifier.fillMaxWidth()
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        val iconRes = when (temp) {
                            in -30..12 -> R.drawable.snowflakes
                            in 13..25 -> R.drawable.thermometerwarm
                            in 26..55 -> R.drawable.sun
                            else -> R.drawable.thermometer
                        }
                        Image(
                            painter = painterResource(id = iconRes),
                            contentDescription = "Temperature Icon",
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("$temp°C / ${celsiusAFahrenheit(temp)}°F", fontSize = 20.sp)
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun AppTemperaturaPreview() {
    AppTemperatura(navegarHoras = {}, navegarTelefonos = {})
}
