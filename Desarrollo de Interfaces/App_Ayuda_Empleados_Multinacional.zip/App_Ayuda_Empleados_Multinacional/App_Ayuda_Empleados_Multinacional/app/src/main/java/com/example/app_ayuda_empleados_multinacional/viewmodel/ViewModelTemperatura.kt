package com.example.app_ayuda_empleados_multinacional.viewmodel

import androidx.lifecycle.ViewModel
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class ViewModelTemperatura : ViewModel() {
    var temperaturaCelsius by mutableStateOf(0f)
        private set
    var usarFarenheit by mutableStateOf(false)
        private set
    var guardarTemperaturas = mutableStateListOf<Int>()
        private set

    fun updateTemperature(value: Float) {
        temperaturaCelsius = value
    }

    fun toggleFahrenheit() {
        usarFarenheit = !usarFarenheit
    }

    fun saveTemperature() {
        if (guardarTemperaturas.size >= 50) {
            guardarTemperaturas.removeAt(0)
        }
        guardarTemperaturas.add(temperaturaCelsius.toInt())
    }

}