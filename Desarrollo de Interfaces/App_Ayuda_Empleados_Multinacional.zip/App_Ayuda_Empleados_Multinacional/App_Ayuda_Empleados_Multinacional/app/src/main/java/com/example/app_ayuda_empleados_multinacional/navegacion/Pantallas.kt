package com.example.app_ayuda_empleados_multinacional.navegacion


import kotlinx.serialization.Serializable

@Serializable
object PantallaTemperatura
@Serializable
object PantallaHoras
@Serializable
object PantallaTelefonos